#ifndef UTIL_H
#define UTIL_H

#include <string>

std::string formatarNomeArmazem(int id);

#endif
